package com.example.glass123.glasslogin.Bluetooth;

/**
 * Created by 海馬瀨人 on 2015/9/1.
 */
public class Profile {

    public String USER_EMAIL="";
    public String USER_NAME="";
    public String USER_IMAGE="";
    public String USER_SEX="";
    public String USER_AGE="";
}
